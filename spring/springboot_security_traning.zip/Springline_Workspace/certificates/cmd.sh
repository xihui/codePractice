#!/bin/bash

### Use this password for all password prompts: [type]password
###
### Simple password, not good security practice, but OK just for learning as you complete lab.

# Generate self-signed certificate authority (CA) cert (will be "trusted," used to sign other certs)
# Using passphrase: capassword
openssl genrsa -aes256 -out ca.key 2048
openssl req -x509 -new -nodes -subj '/C=US/O=CDD CA/CN=localhost' -key ca.key -sha256 -days $((10*366)) -out ca.pem

# Generate client private key + cert signed with CA cert
# Using passphrase: clientpassword
mkdir client
cd client
openssl genrsa -aes256 -out client.key 2048
openssl req -new -sha256 -subj '/C=US/O=Springline Web/CN=localhost' -key client.key -out client.csr
openssl x509 -req -CA ../ca.pem -CAkey ../ca.key -in client.csr -out client.cer -days $((10*366)) -CAcreateserial

# Generate server private key + cert signed with CA cert
# Using passphrase: serverpassword
cd ..
mkdir server
cd server
openssl genrsa -aes256 -out server.key 2048
openssl req -new -sha256 -subj '/C=US/O=Spring Services/CN=localhost' -key server.key -out server.csr
openssl x509 -req -CA ../ca.pem -CAkey ../ca.key -in server.csr -out server.cer -days $((10*366)) -CAcreateserial

# Remove certificate signing request files (no longer needed)
cd ..
rm client/*.csr
rm server/*.csr

# Import server private key + cert to Java (JKS) keystore, for Springline Services app
# Using passphrase: serverpassword
openssl pkcs12 -export -name server -in server/server.cer -inkey server/server.key -out server/server.p12
keytool -importkeystore -srckeystore server/server.p12 -destkeystore server/server.jks
keytool -importcert -file ca.pem -alias ca -keystore ca.jks -noprompt

# Import client private key + cert to Java (JKS) keystore, for Springline Web app
# Using passphrase: clientpassword
openssl pkcs12 -export -name client -in client/client.cer -inkey client/client.key -out client/client.p12
keytool -importkeystore -srckeystore client/client.p12 -destkeystore client/client.jks

# Move/copy files into position to use in apps
cp ca.jks server/server.jks ../springline.services/src/main/resources/
cp ca.jks client/client.jks ../springline/src/main/resources/