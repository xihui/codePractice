#!/bin/bash

openssl x509 -in client/client.cer -pubkey -noout | openssl rsa -pubin -outform der | openssl dgst -sha256 -binary | openssl enc -base64
#Lr+wQq7SmWiJj9Xg4U2ZB/ihxktH17CXgovnfjamo/o=

# Alternate way using the client key file
#openssl rsa -in client/client.key -outform der -pubout | openssl dgst -sha256 -binary | openssl enc -base64
#Lr+wQq7SmWiJj9Xg4U2ZB/ihxktH17CXgovnfjamo/o=

# Removing key pins from Firefox on OSX
# /Users/[username]/Library/Application Support/Firefox/Profiles/[random].default