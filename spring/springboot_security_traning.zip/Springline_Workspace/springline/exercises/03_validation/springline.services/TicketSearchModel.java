package net.cddexploit.training.models;

import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TicketSearchModel {

	@Pattern(regexp = "|(^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$)")
	private String submittedBy;

	@Pattern(regexp = "|(^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$)")
    private String caller;
    
	@Pattern(regexp = "|(^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$)")
	private String dueDate;
    
	@Pattern(regexp = "|(^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$)")
    private String status;

    
    public String getSubmittedBy() {
		return submittedBy;
	}

	public void setSubmittedBy(String submittedBy) {
		this.submittedBy = submittedBy;
	}

	public String getCaller() {
		return caller;
	}

	public void setCaller(String caller) {
		this.caller = caller;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}   
}
