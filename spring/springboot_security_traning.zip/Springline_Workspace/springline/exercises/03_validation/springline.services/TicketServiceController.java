package net.cddexploit.training.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.inject.Inject;
import javax.sql.DataSource;
import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import net.cddexploit.customerservice.config.customerServicePersistenceConfig;
import net.cddexploit.customerservice.entities.Customer;
import net.cddexploit.customerservice.entities.Employee;
import net.cddexploit.customerservice.entities.KnowledgeBase;
import net.cddexploit.customerservice.entities.Ticket;
import net.cddexploit.customerservice.services.TicketService;
import net.cddexploit.training.models.TicketSearchModel;

@RestController
public class TicketServiceController {

	@Inject
	TicketService service;
	
	@Inject
	private customerServicePersistenceConfig persistenceConfig;
	
	@RequestMapping(path = "/api/ticket/{id}", method = RequestMethod.GET)
	public ResponseEntity<Ticket> getTicket(@PathVariable int id) {
		Ticket t = service.findById(id);
		if(t != null) {
			return new ResponseEntity<Ticket>(t, HttpStatus.OK);
		}
		else
			return new ResponseEntity<Ticket>(HttpStatus.NOT_FOUND);
	}

	@RequestMapping(path = "/api/ticket", method = RequestMethod.POST)
	public ResponseEntity<Ticket> postTicket(@RequestBody Ticket ticket) {
		Ticket t = service.findById(ticket.getId());
		
		//Set the properties
		t.setComments(ticket.getComments());
		t.setDescription(ticket.getDescription());
		
		service.save(t);
		
		return new ResponseEntity<Ticket>(t, HttpStatus.OK);
	}

	@RequestMapping(path = "/api/ticket/search", method = RequestMethod.POST)
	public ResponseEntity<ArrayList<Ticket>> searchTickets(@Valid @RequestBody TicketSearchModel search) {
		
		ArrayList<Ticket> tickets;
		
		try {
			tickets = getTicketSearch(search.getSubmittedBy(), search.getStatus(), search.getCaller(), search.getDueDate());
			return new ResponseEntity<ArrayList<Ticket>>(tickets, HttpStatus.OK);
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			return new ResponseEntity<ArrayList<Ticket>>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	private ArrayList<Ticket> getTicketSearch(String submittedBy, String status,
			String caller, String dueDate) throws SQLException {
		
		//Stand up the tickets list
		ArrayList<Ticket> tickets = new ArrayList<Ticket>();
		
		//Grab the data source from JPA
		DataSource ds = persistenceConfig.dataSource();

		//Query objects
		CallableStatement stmt = null;
		ResultSet rs = null;

		try (Connection con = ds.getConnection()) {
			
			stmt = con.prepareCall("{call ticketSearch_Vulnerable(?, ?, ?, ?)}");
			stmt.setString(1, submittedBy);
			stmt.setString(2, status);
			stmt.setString(3, caller);
			stmt.setString(4, dueDate);
			
			//Run the proc
			rs = stmt.executeQuery();
			
			while(rs.next()) {
				//Load the ticket entity object
				Ticket ticketEntity = getTicketFromResultSet(rs);
				
				//Add the ticket to the list
				tickets.add(ticketEntity);				
			}
		}
		
		return tickets;
	}

	private Ticket getTicketFromResultSet(ResultSet rs) throws SQLException {
		Ticket t = new Ticket();
		t.setId(rs.getInt("id"));
		t.setTitle(rs.getString("title"));
		t.setOpenedDate(rs.getTimestamp("opened_date"));
		t.setStatus(rs.getString("status"));
		t.setCategory(rs.getString("category"));
		t.setPriority(rs.getString("priority"));
		t.setDueDate(rs.getTimestamp("due_date"));

		//Add employee
		Employee openedBy = new Employee();
		openedBy.setId(rs.getInt("opened_by_id"));
		openedBy.setFirstName(rs.getString("openedby_first_name"));
		openedBy.setLastName(rs.getString("openedby_last_name"));
		t.setOpenedBy(openedBy);
		
		//Add caller
		Customer caller = new Customer();
		caller.setId(rs.getInt("caller_id"));
		caller.setFirstName(rs.getString("customer_first_name"));
		caller.setLastName(rs.getString("customer_last_name"));
		t.setCustomer(caller);
		
		//Add KB
		KnowledgeBase kb = new KnowledgeBase();
		kb.setTitle(rs.getString("kb_title"));
		kb.setUrl(rs.getString("kb_url"));
		t.setKnowledgeBase(kb);
		return t;
	}
}
