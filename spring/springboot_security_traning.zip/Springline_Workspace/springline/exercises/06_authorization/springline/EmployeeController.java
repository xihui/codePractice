package net.cddexploit.training.controllers.humanresources;

import java.sql.SQLException;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import net.cddexploit.customerservice.entities.Employee;
import net.cddexploit.customerservice.entities.User;
import net.cddexploit.customerservice.repositories.EmployeeRepository;
import net.cddexploit.customerservice.repositories.UserRepository;

@Controller
public class EmployeeController {

	private static final String EMPLOYEE_VIEW_NAME = "humanresources/employee";
	private static final String MANAGE_VIEW_NAME = "humanresources/manage";
	
	@Value("${springline.service.url}")
	private String serviceUrl;
	
	@Autowired
    private RestTemplate restTemplate;
	
	@RequestMapping(value = MANAGE_VIEW_NAME, method = RequestMethod.GET)
	@PreAuthorize("hasAuthority('Manager')")
	public String getManage(Model model) {
		//TO DO: Make this dynamic and read direct reports from the database
		return MANAGE_VIEW_NAME;
	}
	
	@RequestMapping(value = EMPLOYEE_VIEW_NAME, method = RequestMethod.GET)
	public String getEmployee(Model model, HttpServletRequest req) throws SQLException {
		
		Employee employee = null;
		
		if(req.getParameter("id") != null && !req.getParameter("id").isEmpty()) {
			int id = Integer.valueOf(req.getParameter("id"));

			ResponseEntity<Employee> entity = restTemplate.getForEntity(String.format("%s/employee/%s", serviceUrl, id), Employee.class);
			
			if(entity.getStatusCode() == HttpStatus.OK) {
				employee = entity.getBody();
			}
		}
		else {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			
			ResponseEntity<Employee> entity = restTemplate.getForEntity(String.format("%s/employee/user/%s", serviceUrl, auth.getName()), Employee.class);
			
			if(entity.getStatusCode() == HttpStatus.OK) {
				employee = entity.getBody();
			}
		}

		//Add object to the model
		model.addAttribute("employee", employee);
		
        return EMPLOYEE_VIEW_NAME;
    }
}
