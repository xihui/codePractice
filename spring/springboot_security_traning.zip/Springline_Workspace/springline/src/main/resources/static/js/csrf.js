window.onload = function() {
	document.getElementById("csrfForm").submit();
}
	
// defeat frame busters
//window.onbeforeunload = function() {
//    return "Please click 'Stay on this page' to allow it to finish loading.";
//}